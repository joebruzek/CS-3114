import junit.framework.TestCase;


public class TestMain extends TestCase
{

    public void testMain()
    {
       SearchTree.main(new String[] {"10", "32", "src/reference_input3_SimpleInsertWithPrintBlocks.txt"});
    }

}